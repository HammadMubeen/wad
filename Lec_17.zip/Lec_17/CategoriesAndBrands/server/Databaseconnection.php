<?php
	$con=mysqli_connect("localhost","root","","Tech_Box_Database");

	if(!$con)
	{
	    die("Error");
 	}
?>